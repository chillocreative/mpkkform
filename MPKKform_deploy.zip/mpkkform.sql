-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 06, 2026 at 12:38 PM
-- Server version: 8.4.3
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mpkkform`
--

-- --------------------------------------------------------

--
-- Table structure for table `mpkk_attendance`
--

CREATE TABLE `mpkk_attendance` (
  `id` int NOT NULL,
  `nama_penuh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_kad_pengenalan` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_telefon` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jawatan` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama_mpkk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `daerah` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `negeri` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tarikh_kehadiran` date NOT NULL,
  `masa_kehadiran` time NOT NULL,
  `tujuan_kehadiran` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mpkk_attendance`
--

INSERT INTO `mpkk_attendance` (`id`, `nama_penuh`, `no_kad_pengenalan`, `no_telefon`, `email`, `jawatan`, `nama_mpkk`, `daerah`, `negeri`, `tarikh_kehadiran`, `masa_kehadiran`, `tujuan_kehadiran`, `catatan`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Ahmad bin Abdullah', '900101-01-1234', '012-3456789', 'ahmad@email.com', 'Pengerusi', 'MPKK Kampung Baru', 'Kuala Lumpur', 'Wilayah Persekutuan Kuala Lumpur', '1970-01-01', '10:00:00', 'Mesyuarat bulanan MPKK untuk membincangkan projek pembangunan komuniti', 'Kehadiran penuh ahli jawatankuasa', 'approved', '2026-01-06 11:18:34', '2026-01-06 11:26:08');

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `id` int NOT NULL,
  `nama` varchar(255) NOT NULL,
  `no_tel` varchar(20) NOT NULL,
  `no_ic` varchar(20) NOT NULL,
  `mpkk` varchar(100) NOT NULL,
  `jawatan` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`id`, `nama`, `no_tel`, `no_ic`, `mpkk`, `jawatan`, `created_at`) VALUES
(1, 'Admin User', '019-9999999', '900101-01-5000', 'MPKK BERTAM INDAH', 'Pengerusi', '2026-01-06 09:38:55'),
(2, 'JOHN DOE', '012345', '900101075555', 'MPKK BERTAM INDAH', 'Pengerusi', '2026-01-06 09:54:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mpkk_attendance`
--
ALTER TABLE `mpkk_attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_no_kad` (`no_kad_pengenalan`),
  ADD KEY `idx_tarikh` (`tarikh_kehadiran`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `registrations`
--
ALTER TABLE `registrations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mpkk_attendance`
--
ALTER TABLE `mpkk_attendance`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registrations`
--
ALTER TABLE `registrations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
